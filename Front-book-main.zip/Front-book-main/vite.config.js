import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  optimizeDeps: {
    include: ['pdfjs-dist/build/pdf.worker.entry']
  },
  build: {
    commonjsOptions: {
      include: [/pdfjs-dist/]
    }
  },
})
