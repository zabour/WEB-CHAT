
import { createContext, useState, useEffect } from "react";
import PropTypes from "prop-types";
import Cookies from "js-cookie";

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(
    () => Cookies.get("isAuthenticated") === "true"
  );

  const [token, setToken] = useState(() => Cookies.get("token") || null);

  const [user, setUser] = useState(() => {
    const userData = Cookies.get("user");
    return userData ? JSON.parse(userData) : null;
  });

  const authenticate = () => {
    setIsAuthenticated(true);
    Cookies.set("isAuthenticated", "true", { expires: 5 });
  };

  const signIn = (userData, tokenData) => {
    setIsAuthenticated(true);
    setUser(userData);
    setToken(tokenData);
    Cookies.set("isAuthenticated", "true", { expires: 7 }); 
    Cookies.set("user", JSON.stringify(userData), { expires: 7 });
    localStorage.setItem("user", JSON.stringify(userData), { expires: 7 });
    Cookies.set("token", tokenData, { expires: 7 }); 
  };

  const signOut = () => {
    setIsAuthenticated(false);
    setUser(null);
    setToken(null);
    Cookies.remove("isAuthenticated");
    Cookies.remove("user");
    Cookies.remove("token");
  };

  useEffect(() => {
    const handleStorageChange = () => {
      setIsAuthenticated(Cookies.get("isAuthenticated") === "true");
      const storedUser = Cookies.get("user");
      setUser(storedUser ? JSON.parse(storedUser) : null);
      setToken(Cookies.get("token") || null);
    };

    window.addEventListener("storage", handleStorageChange);
    return () => window.removeEventListener("storage", handleStorageChange);
  }, []);

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        authenticate,
        signIn,
        signOut,
        token,
        user,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

AuthProvider.propTypes = {
  children: PropTypes.node.isRequired,
};
