import { useState, useEffect } from "react";
import { Dialog, Transition } from "@headlessui/react";
import Cookies from "js-cookie";
import book from "/open-book.png";

export default function ContactsList() {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedContact, setSelectedContact] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);

  const apiBaseUrl = import.meta.env.VITE_API_URI;

  const fetchbooks = async () => {
    const token = Cookies.get("token");

    try {
      const response = await fetch(`${apiBaseUrl}/books/getAll`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        setError("Network issue, please refresh the page.");
        return;
      }

      const data = await response.json();
      setBooks(data);
      setError(null);
    } catch (error) {
      setError("Network issue, please refresh the page.");
      console.error("Failed to fetch contacts:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadPdf = async (bookId) => {
    try {
      // Get your auth token (adjust this according to how you store it)
      const token = Cookies.get("token");// or however you store your token
      
      const response = await fetch(`${apiBaseUrl}/books/download-pdf/${bookId}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
  
      if (!response.ok) {
        throw new Error('Download failed');
      }
  
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      
      // Create and trigger download
      const link = document.createElement('a');
      link.href = url;
      link.download = `book.pdf`; // The actual filename will be set by the server
      
      document.body.appendChild(link);
      link.click();
      
      // Cleanup
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Failed to download PDF:", error);
    }
  };
  
  
  const deleteContact = async (contactId) => {
    const token = Cookies.get("token");

    try {
      const response = await fetch(`${apiBaseUrl}/books/${contactId}`, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        setError("Failed to delete contact. Please try again.");
        return;
      }

      setBooks(books.filter((contact) => contact._id !== contactId));
      setError(null);
    } catch (error) {
      setError("Failed to delete contact. Please try again.");
      console.error("Failed to delete contact:", error);
    } finally {
      setIsDeleteConfirmOpen(false);
      setSelectedContact(null);
    }
  };

  const openModal = (contact) => {
    setSelectedContact(contact);
    setIsModalOpen(true);
    setIsEditMode(false);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedContact(null);
  };

  const openForm = () => {
    setIsFormOpen(true);
  };

  const closeForm = () => {
    setIsFormOpen(false);
  };

  const handleEditClick = () => {
    setIsEditMode(true);
  };

  const handleAddBook = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    const token = Cookies.get("token");
  
    // Form data
    const bookName = e.target.bookName.value;
    const pdfFile = e.target.pdfFile.files[0];
    const imageFile = e.target.imageFile.files[0];
    const genre = e.target.genre.value;
    const auteurs = e.target.auteurs.value;
    const nb_page = e.target.nb_page.value;
    const date_edition = e.target.date_edition.value;
    const prix = e.target.prix.value;
    const description = e.target.description.value;
  
    try {
      // Prepare FormData object
      const formData = new FormData();
      formData.append("name", bookName);
      if (pdfFile) formData.append("filePdf", pdfFile);
      if (imageFile) formData.append("image", imageFile);
      formData.append("genre", genre);
      formData.append("auteurs", auteurs);
      if (nb_page) formData.append("nb_page", parseInt(nb_page, 10));
      if (date_edition) formData.append("date_edition", date_edition);
      if (prix) formData.append("prix", parseFloat(prix));
      if (description) formData.append("description", description);
  
      // Send request to backend
      const response = await fetch(`${apiBaseUrl}/books/add`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`, // Authorization header
        },
        body: formData, // Attach FormData
      });
  
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
  
      const addedBook = await response.json();
      console.log("Book added successfully:", addedBook);
      setError(null);
      closeForm();
    } catch (error) {
      setError("Failed to add book. Please try again.");
      console.error("Failed to add book:", error);
    } finally {
      setIsLoading(false);
    }
  };
  

  const handleUpdateContact = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    const token = Cookies.get("token");

    const updatedContact = {
      firstName: e.target.firstName.value,
      lastName: e.target.lastName.value,
      email: e.target.email.value,
      phoneNumber: e.target.phoneNumber.value,
      address: e.target.address.value,
      gender: e.target.gender.value,
      linkedinLink: e.target.linkedinLink.value,
      facebookLink: e.target.facebookLink.value,
    };

    try {
      const response = await fetch(
        `${apiBaseUrl}/books/${selectedContact._id}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify(updatedContact),
        }
      );

      if (!response.ok) {
        setError("Failed to update contact. Please try again.");
        return;
      }

      const updatedData = await response.json();
      setBooks(
        books.map((contact) =>
          contact._id === selectedContact._id ? updatedData : contact
        )
      );
      setError(null);
      closeModal();
    } catch (error) {
      setError("Failed to update contact. Please try again.");
      console.error("Failed to update contact:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteClick = (contact) => {
    setSelectedContact(contact);
    setIsDeleteConfirmOpen(true);
  };

  const handleConfirmDelete = () => {
    if (selectedContact) {
      deleteContact(selectedContact._id);
    }
  };

  useEffect(() => {
    fetchbooks();
  }, []);

  return (
    <>
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-900">
          {isFormOpen ? "Add New Book" : "Books"}
        </h1>
        <button
          onClick={isFormOpen ? closeForm : openForm}
          className="inline-flex items-center justify-center rounded-md bg-black px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
        >
          {isFormOpen ? "Return to Books" : "Add Book"}
        </button>
      </div>

      {error && <div className="mt-4 text-red-600">{error}</div>}

      {loading ? (
        <p>Loading books...</p>
      ) :isFormOpen ? (
        <div className="mt-10 sm:mx-auto sm:w-full sm:max-w-lg">
          <form onSubmit={handleAddBook} className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div>
                <label
                  htmlFor="bookName"
                  className="block text-sm font-medium leading-6 text-gray-900"
                >
                  Book Name
                </label>
                <div className="mt-2">
                  <input
                    id="bookName"
                    name="bookName"
                    type="text"
                    required
                    pattern="^[a-zA-Z0-9 ]{3,}$"
                    title="Book name should be at least 3 characters long and contain only letters, numbers, and spaces."
                    className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-gray-500 sm:text-sm sm:leading-6"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="pdfFile"
                  className="block text-sm font-medium leading-6 text-gray-900"
                >
                  PDF File
                </label>
                <div className="mt-2">
                  <input
                    id="pdfFile"
                    name="pdfFile"
                    type="file"
                    accept="application/pdf"
                    required
                    className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-gray-500 sm:text-sm sm:leading-6"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="imageFile"
                  className="block text-sm font-medium leading-6 text-gray-900"
                >
                  Image File
                </label>
                <div className="mt-2">
                  <input
                    id="imageFile"
                    name="imageFile"
                    type="file"
                    accept="image/*"
                    className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-gray-500 sm:text-sm sm:leading-6"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="genre"
                  className="block text-sm font-medium leading-6 text-gray-900"
                >
                  Genre
                </label>
                <div className="mt-2">
                  <select
                    id="genre"
                    name="genre"
                    required
                    className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-gray-500 sm:text-sm sm:leading-6"
                  >
                    <option value="">Select a genre</option>
                    <option value="Big data">Big data</option>
                    <option value="Science">Science</option>
                    <option value="IT">IT</option>
                    <option value="Management">Management</option>
                    <option value="BI">BI</option>
                  </select>
                </div>
              </div>

              <div>
                <label
                  htmlFor="auteurs"
                  className="block text-sm font-medium leading-6 text-gray-900"
                >
                  Auteur
                </label>
                <div className="mt-2">
                  <input
                    id="auteurs"
                    name="auteurs"
                    type="text"
                    className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-gray-500 sm:text-sm sm:leading-6"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="nb_page"
                  className="block text-sm font-medium leading-6 text-gray-900"
                >
                  Number of Pages
                </label>
                <div className="mt-2">
                  <input
                    id="nb_page"
                    name="nb_page"
                    type="number"
                    className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-gray-500 sm:text-sm sm:leading-6"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="date_edition"
                  className="block text-sm font-medium leading-6 text-gray-900"
                >
                  Date of Edition
                </label>
                <div className="mt-2">
                  <input
                    id="date_edition"
                    name="date_edition"
                    type="date"
                    className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-gray-500 sm:text-sm sm:leading-6"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="prix"
                  className="block text-sm font-medium leading-6 text-gray-900"
                >
                  Price
                </label>
                <div className="mt-2">
                  <input
                    id="prix"
                    name="prix"
                    type="number"
                    step="0.01"
                    className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-gray-500 sm:text-sm sm:leading-6"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="description"
                  className="block text-sm font-medium leading-6 text-gray-900"
                >
                  Description
                </label>
                <div className="mt-2">
                  <textarea
                    id="description"
                    name="description"
                    maxLength="300"
                    className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-gray-500 sm:text-sm sm:leading-6"
                  ></textarea>
                </div>
              </div>
            </div>

            <div className="mt-6 flex justify-end space-x-2">
              <button
                type="button"
                className="inline-flex justify-center rounded-md border border-transparent bg-gray-600 px-4 py-2 text-sm font-medium text-white hover:bg-gray-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-gray-500 focus-visible:ring-offset-2 transition duration-200"
                onClick={closeForm}
              >
                Cancel
              </button>
              <button
                type="submit"
                className="inline-flex justify-center rounded-md border border-transparent bg-black px-4 py-2 text-sm font-medium text-white hover:bg-gray-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-gray-500 focus-visible:ring-offset-2 transition duration-200"
                disabled={isLoading}
              >
                {isLoading ? "Adding book..." : "Add Book"}
              </button>
            </div>
          </form>
        </div>
      ) : (
        <>
          {books.length > 0 ? (
            <section
              role="list"
              className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 mt-6"
            >
              {books.map((contact) => (
                <article
                  key={contact._id}
                  className="col-span-1 divide-y divide-gray-200 rounded-lg bg-white shadow"
                >
                  <header className="flex w-full items-center justify-between space-x-6 p-6">
                    <div className="flex-1 truncate">
                      <h3 className="truncate text-sm font-medium text-gray-900">
                        {`${contact.name}`}
                      </h3>
                    </div>
                    <img
                      alt={`${contact.name}`}
                      src={book}
                      className="h-14 w-14 flex-shrink-0 rounded-full bg-white"
                    />
                  </header>
                  <footer className="flex justify-between space-x-4 p-4 bg-gradient-to-r from-gray-50 via-gray-100 to-gray-50 rounded-b-lg shadow-lg">
                    <button
                      onClick={() => openModal(contact)}
                      className="flex-1 inline-flex items-center justify-center gap-x-3 rounded-lg border border-transparent py-3 text-sm font-semibold text-white bg-black hover:bg-gray-800 shadow-md transform transition duration-300 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
                    >
                      View Details
                    </button>
                    <button
                      onClick={() => handleDeleteClick(contact)}
                      className="flex-1 inline-flex items-center justify-center gap-x-3 rounded-lg border border-transparent py-3 text-sm font-semibold text-white bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 shadow-md transform transition duration-300 hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                    >
                      Delete book
                    </button>
                  </footer>
                </article>
              ))}
            </section>
          ) : (
            <p>No books added.</p>
          )}
        </>
      )}

      {selectedContact && (
        <Transition appear show={isModalOpen} as="Fragment">
          <Dialog as="div" className="relative z-10" onClose={closeModal}>
            <Transition.Child
              as="Fragment"
              enter="ease-out duration-300"
              enterFrom="opacity-0"
              enterTo="opacity-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100"
              leaveTo="opacity-0"
            >
              <div className="fixed inset-0 bg-black bg-opacity-25" />
            </Transition.Child>

            <div className="fixed inset-0 overflow-y-auto">
              <div className="flex min-h-full items-center justify-center p-4 text-center">
                <Transition.Child
                  as="Fragment"
                  enter="ease-out duration-300"
                  enterFrom="opacity-0 scale-95"
                  enterTo="opacity-100 scale-100"
                  leave="ease-in duration-200"
                  leaveFrom="opacity-100 scale-100"
                  leaveTo="opacity-0 scale-95"
                >
                  <Dialog.Panel className="w-full max-w-3xl transform overflow-hidden rounded-2xl bg-white p-6 text-left align-middle shadow-xl transition-all">
                    <Dialog.Title
                      as="h3"
                      className="text-lg font-medium leading-6 text-gray-900"
                    >
                      {isEditMode ? "Edit Contact" : "Contact Details"}
                    </Dialog.Title>

                    {isEditMode ? (
                      <form
                        onSubmit={handleUpdateContact}
                        className="space-y-6"
                      >
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                          <div>
                            <label
                              htmlFor="firstName"
                              className="block text-sm font-medium leading-6 text-gray-900"
                            >
                              First Name
                            </label>
                            <div className="mt-2">
                              <input
                                id="firstName"
                                name="firstName"
                                type="text"
                                defaultValue={selectedContact.firstName}
                                required
                                pattern="^[a-zA-Z ]{3,}$"
                                title="First name should be at least 3 characters long and contain only letters and spaces."
                                className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-gray-500 sm:text-sm sm:leading-6"
                              />
                            </div>
                          </div>

                          <div>
                            <label
                              htmlFor="lastName"
                              className="block text-sm font-medium leading-6 text-gray-900"
                            >
                              Last Name
                            </label>
                            <div className="mt-2">
                              <input
                                id="lastName"
                                name="lastName"
                                type="text"
                                defaultValue={selectedContact.lastName}
                                required
                                pattern="^[a-zA-Z ]{3,}$"
                                title="Last name should be at least 3 characters long and contain only letters and spaces."
                                className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-gray-500 sm:text-sm sm:leading-6"
                              />
                            </div>
                          </div>

                          <div>
                            <label
                              htmlFor="email"
                              className="block text-sm font-medium leading-6 text-gray-900"
                            >
                              Email address
                            </label>
                            <div className="mt-2">
                              <input
                                id="email"
                                name="email"
                                type="email"
                                defaultValue={selectedContact.email}
                                required
                                className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-gray-500 sm:text-sm sm:leading-6"
                              />
                            </div>
                          </div>

                          <div>
                            <label
                              htmlFor="phoneNumber"
                              className="block text-sm font-medium leading-6 text-gray-900"
                            >
                              Phone Number
                            </label>
                            <div className="mt-2">
                              <input
                                id="phoneNumber"
                                name="phoneNumber"
                                type="text"
                                defaultValue={selectedContact.phoneNumber}
                                required
                                pattern="^[0-8]{8}$"
                                title="Phone number should be exactly 8 digits."
                                className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-gray-500 sm:text-sm sm:leading-6"
                              />
                            </div>
                          </div>

                          <div>
                            <label
                              htmlFor="address"
                              className="block text-sm font-medium leading-6 text-gray-900"
                            >
                              Address
                            </label>
                            <div className="mt-2">
                              <input
                                id="address"
                                name="address"
                                type="text"
                                defaultValue={selectedContact.address}
                                required
                                className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-gray-500 sm:text-sm sm:leading-6"
                              />
                            </div>
                          </div>

                          <div>
                            <label
                              htmlFor="gender"
                              className="block text-sm font-medium leading-6 text-gray-900"
                            >
                              Gender
                            </label>
                            <div className="mt-2">
                              <select
                                id="gender"
                                name="gender"
                                defaultValue={selectedContact.gender}
                                required
                                className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-gray-500 sm:text-sm sm:leading-6"
                              >
                                <option value="">Select Gender</option>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                              </select>
                            </div>
                          </div>

                          <div>
                            <label
                              htmlFor="linkedinLink"
                              className="block text-sm font-medium leading-6 text-gray-900"
                            >
                              LinkedIn Link
                            </label>
                            <div className="mt-2">
                              <input
                                id="linkedinLink"
                                name="linkedinLink"
                                type="url"
                                defaultValue={selectedContact.linkedinLink}
                                pattern="https?://.+"
                                title="Please enter a valid URL."
                                className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-gray-500 sm:text-sm sm:leading-6"
                              />
                            </div>
                          </div>

                          <div>
                            <label
                              htmlFor="facebookLink"
                              className="block text-sm font-medium leading-6 text-gray-900"
                            >
                              Facebook Link
                            </label>
                            <div className="mt-2">
                              <input
                                id="facebookLink"
                                name="facebookLink"
                                type="url"
                                defaultValue={selectedContact.facebookLink}
                                pattern="https?://.+"
                                title="Please enter a valid URL."
                                className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-gray-500 sm:text-sm sm:leading-6"
                              />
                            </div>
                          </div>
                        </div>

                        <div className="mt-6 flex justify-end space-x-2">
                          <button
                            type="button"
                            className="inline-flex justify-center rounded-md border border-transparent bg-gray-600 px-4 py-2 text-sm font-medium text-white hover:bg-gray-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-gray-500 focus-visible:ring-offset-2 transition duration-200"
                            onClick={() => setIsEditMode(false)}
                          >
                            Cancel
                          </button>
                          <button
                            type="submit"
                            className="inline-flex justify-center rounded-md border border-transparent bg-black px-4 py-2 text-sm font-medium text-white hover:bg-gray-800 focus:outline-none focus-visible:ring-2 focus-visible:ring-gray-500 focus-visible:ring-offset-2 transition duration-200"
                            disabled={isLoading}
                          >
                            {isLoading ? "Updating..." : "Update"}
                          </button>
                        </div>
                      </form>
                    ) : (
                      <div>
                        <div className="mt-4 space-y-2">
                          <p className="text-sm text-gray-500">
                            <strong>Name:</strong> {`${selectedContact.name} `}
                          </p>
                        </div>

                        <div className="mt-6 flex justify-end space-x-2">
                          <button
                            type="button"
                            className="inline-flex justify-center rounded-md border border-transparent bg-gray-600 px-4 py-2 text-sm font-medium text-white hover:bg-gray-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-gray-500 focus-visible:ring-offset-2 transition duration-200"
                            onClick={handleEditClick}
                          >
                            Edit
                          </button>
                          <button
                            type="button"
                            className="inline-flex justify-center rounded-md border border-transparent bg-red-600 px-4 py-2 text-sm font-medium text-white hover:bg-red-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-red-500 focus-visible:ring-offset-2 transition duration-200"
                            onClick={() => handleDeleteClick(selectedContact)}
                          >
                            Delete
                          </button>
                          <button
                            type="button"
                            className="inline-flex justify-center rounded-md border border-transparent bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 focus-visible:ring-offset-2 transition duration-200"
                            onClick={() => handleDownloadPdf(selectedContact._id)}
                          >
                            Download PDF
                          </button>
                        </div>
                      </div>
                    )}
                  </Dialog.Panel>
                </Transition.Child>
              </div>
            </div>
          </Dialog>
        </Transition>
      )}

      {/* Delete Confirmation Dialog */}
      <Transition appear show={isDeleteConfirmOpen} as="Fragment">
        <Dialog
          as="div"
          className="relative z-10"
          onClose={() => setIsDeleteConfirmOpen(false)}
        >
          <Transition.Child
            as="Fragment"
            enter="ease-out duration-300"
            enterFrom="opacity-0"
            enterTo="opacity-100"
            leave="ease-in duration-200"
            leaveFrom="opacity-100"
            leaveTo="opacity-0"
          >
            <div className="fixed inset-0 bg-black bg-opacity-25" />
          </Transition.Child>

          <div className="fixed inset-0 overflow-y-auto">
            <div className="flex min-h-full items-center justify-center p-4 text-center">
              <Transition.Child
                as="Fragment"
                enter="ease-out duration-300"
                enterFrom="opacity-0 scale-95"
                enterTo="opacity-100 scale-100"
                leave="ease-in duration-200"
                leaveFrom="opacity-100 scale-100"
                leaveTo="opacity-0 scale-95"
              >
                <Dialog.Panel className="w-full max-w-md transform overflow-hidden rounded-2xl bg-white p-6 text-left align-middle shadow-xl transition-all">
                  <Dialog.Title
                    as="h3"
                    className="text-lg font-medium leading-6 text-gray-900"
                  >
                    Confirm Deletion
                  </Dialog.Title>
                  <div className="mt-4">
                    <p className="text-sm text-gray-500">
                      Are you sure you want to delete this contact? This action
                      cannot be undone.
                    </p>
                  </div>

                  <div className="mt-6 flex justify-end space-x-2">
                    <button
                      type="button"
                      className="inline-flex justify-center rounded-md border border-transparent bg-gray-600 px-4 py-2 text-sm font-medium text-white hover:bg-gray-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-gray-500 focus-visible:ring-offset-2 transition duration-200"
                      onClick={() => setIsDeleteConfirmOpen(false)}
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      className="inline-flex justify-center rounded-md border border-transparent bg-red-600 px-4 py-2 text-sm font-medium text-white hover:bg-red-700 focus:outline-none focus-visible:ring-2 focus-visible:ring-red-500 focus-visible:ring-offset-2 transition duration-200"
                      onClick={handleConfirmDelete}
                    >
                      Confirm
                    </button>
                  </div>
                </Dialog.Panel>
              </Transition.Child>
            </div>
          </div>
        </Dialog>
      </Transition>
    </>
  );
}
