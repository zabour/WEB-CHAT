
export default function NotfoundPage() {
  return (
    <div><h2>404 Not Found</h2></div>
  )
}
