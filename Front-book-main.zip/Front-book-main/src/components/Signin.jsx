/* eslint-disable no-unused-vars */
import { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import book from "/open-book.png";
import { AuthContext } from "../context/AuthContext";
import { Link } from "react-router-dom";

export default function Signin() {
  const apiBaseUrl = import.meta.env.VITE_API_URI;

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const navigate = useNavigate();

  const { signIn, authenticate } = useContext(AuthContext);

  // Handle form submission
  const handleSubmit = async (event) => {
    // event.preventDefault();
    // setIsLoading(true);
    // setError("");

    // if (!email || !password) {
    //   setError("Both email and password are required.");
    //   setIsLoading(false);
    //   return;
    // }

    // try {
    //   const response = await fetch(`${apiBaseUrl}/users/auth`, {
    //     method: "POST",
    //     headers: {
    //       "Content-Type": "application/json",
    //     },
    //     body: JSON.stringify({ email, password }),
    //   });

    //   const data = await response.json();

    //   // Handle specific status codes
    //   if (response.status === 403) {
    //     setError("Account not verified.");
    //   } else if (response.status === 409) {
    //     setError("Password or email incorrect.");
    //   } else if (response.status === 404) {
    //     setError("User not found.");
    //   } else if (response.status === 500) {
    //     setError("Network issue. Please try again later.");
    //   } else if (response.ok) {
    //     // On successful login, use the signIn function from context and authenticate the user
    //     signIn(data.user, data.token);
    //     authenticate();  // Set isAuthenticated to true in the context
        navigate("/books");
    //   } else {
    //     setError("Internal Server Error");
    //   }
    // } catch (err) {
    //   console.log(err);
    //   setError("A problem occurred, please try again.");
    // } finally {
    //   setIsLoading(false);
    // }
  };

  return (
    <>
      <div className="flex min-h-full flex-1 flex-col justify-center px-6 py-12 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-sm">
          <img alt="Your Company" src={book} className="mx-auto h-28 w-auto" />
          <h2 className="mt-10 text-center text-2xl font-bold leading-9 tracking-tight text-gray-900">
            Sign in to your account
          </h2>
        </div>

        <div className="mt-10 sm:mx-auto sm:w-full sm:max-w-sm">
          {/* Error message */}
          {error && (
            <div className="mb-4 text-red-600 text-center">{error}</div>
          )}
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label
                htmlFor="email"
                className="block text-sm font-medium leading-6 text-gray-900"
              >
                Email address
              </label>
              <div className="mt-2">
                <input
                  id="email"
                  name="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  autoComplete="email"
                  className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-gray-500 sm:text-sm sm:leading-6"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between">
                <label
                  htmlFor="password"
                  className="block text-sm font-medium leading-6 text-gray-900"
                >
                  Password
                </label>
                <div className="text-sm">
                  <Link
                    href="#"
                    className="font-semibold text-black hover:text-gray-500"
                  >
                    Forgot password?
                  </Link>
                </div>
              </div>
              <div className="mt-2">
                <input
                  id="password"
                  name="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  autoComplete="current-password"
                  className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-gray-500 sm:text-sm sm:leading-6"
                />
              </div>
            </div>

            <div>
              <button
                type="submit"
                className="flex w-full justify-center rounded-md bg-black px-3 py-1.5 text-sm font-semibold leading-6 text-white shadow-sm hover:bg-gray-800 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gray-500"
                disabled={isLoading}
              >
                {isLoading ? "Signing in..." : "Sign in"}
              </button>
            </div>
          </form>

          <p className="mt-10 text-center text-sm text-gray-500">
            Not a member?{" "}
            <Link
              to="/signup"
              className="font-semibold leading-6 text-black hover:text-gray-800"
            >
              Sign up now!
            </Link>
          </p>
        </div>
      </div>
    </>
  );
}
