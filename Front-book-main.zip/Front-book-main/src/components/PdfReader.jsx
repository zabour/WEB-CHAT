import { useState, useEffect } from 'react';
import { Document, Page } from 'react-pdf';
import { ChevronLeft, ChevronRight, ZoomIn, ZoomOut, X, Loader2 } from 'lucide-react';
import PropTypes from 'prop-types';
import 'react-pdf/dist/esm/Page/TextLayer.css';
import 'react-pdf/dist/esm/Page/AnnotationLayer.css';

// Initialize PDF.js with internal worker
import * as pdfjs from 'pdfjs-dist';
const pdfjsWorker = await import('pdfjs-dist/build/pdf.worker.entry');
pdfjs.GlobalWorkerOptions.workerSrc = pdfjsWorker;

const PDFReader = ({ pdfFile, onClose }) => {
  const [numPages, setNumPages] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [zoom, setZoom] = useState(100);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [pdfData, setPdfData] = useState(null);

  useEffect(() => {
    const loadPDF = async () => {
      try {
        setIsLoading(true);
        setError(null);

        if (!pdfFile) {
          throw new Error('No PDF file provided');
        }

        // Directly use pdfFile if it's a Blob, File, or string (URL)
        if (pdfFile instanceof Blob || pdfFile instanceof File || typeof pdfFile === 'string') {
          setPdfData(pdfFile);
        } else {
          throw new Error('Unsupported PDF input type');
        }
      } catch (err) {
        console.error('Error processing PDF:', err);
        setError(`Error loading PDF: ${err.message}`);
      } finally {
        setIsLoading(false);
      }
    };

    if (pdfFile) {
      loadPDF();
    }

    return () => {
      setPdfData(null);
      setCurrentPage(1);
    };
  }, [pdfFile]);

  const handleDocumentLoadSuccess = ({ numPages }) => {
    setNumPages(numPages);
    setIsLoading(false);
    setError(null);
  };

  const handleDocumentLoadError = (error) => {
    console.error('Error loading PDF:', error);
    setError(`Error loading PDF: ${error.message}`);
    setIsLoading(false);
  };

  const handlePrevPage = () => {
    setCurrentPage(prev => Math.max(1, prev - 1));
  };

  const handleNextPage = () => {
    setCurrentPage(prev => Math.min(numPages, prev + 1));
  };

  const handleZoomIn = () => {
    setZoom(prev => Math.min(200, prev + 10));
  };

  const handleZoomOut = () => {
    setZoom(prev => Math.max(50, prev - 10));
  };

  useEffect(() => {
    const handleKeyPress = (e) => {
      if (e.key === 'ArrowRight') handleNextPage();
      if (e.key === 'ArrowLeft') handlePrevPage();
      if (e.key === 'Escape') onClose();
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [currentPage, numPages, onClose]);

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50">
      <div className="h-screen w-screen flex flex-col p-4">
        {/* Header */}
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center gap-4">
            <button
              onClick={handleZoomOut}
              className="p-2 bg-white rounded-full hover:bg-gray-100"
            >
              <ZoomOut className="w-5 h-5" />
            </button>
            <span className="text-white">{zoom}%</span>
            <button
              onClick={handleZoomIn}
              className="p-2 bg-white rounded-full hover:bg-gray-100"
            >
              <ZoomIn className="w-5 h-5" />
            </button>
          </div>

          <div className="flex items-center gap-2 text-white">
            <span>
              Page {currentPage} of {numPages || '...'}
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-2 bg-white rounded-full hover:bg-gray-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex items-center justify-center relative">
          <button
            onClick={handlePrevPage}
            disabled={currentPage === 1}
            className="absolute left-4 p-4 bg-white rounded-full hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          <div className="w-full max-w-4xl h-full max-h-[90vh] bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="w-full h-full flex items-center justify-center p-4">
              {isLoading && (
                <div className="flex flex-col items-center gap-4">
                  <Loader2 className="w-8 h-8 animate-spin" />
                  <span>Loading PDF...</span>
                </div>
              )}

              {error && (
                <div className="text-red-500">{error}</div>
              )}

              {pdfData && (
                <Document
                  file={pdfData}
                  onLoadSuccess={handleDocumentLoadSuccess}
                  onLoadError={handleDocumentLoadError}
                  loading={null}
                  options={{
                    cMapUrl: 'https://cdn.jsdelivr.net/npm/pdfjs-dist@3.11.174/cmaps/',
                    cMapPacked: true,
                  }}
                >
                  <Page
                    pageNumber={currentPage}
                    scale={zoom / 100}
                    loading={null}
                    className="shadow-lg"
                  />
                </Document>
              )}
            </div>
          </div>

          <button
            onClick={handleNextPage}
            disabled={currentPage === numPages}
            className="absolute right-4 p-4 bg-white rounded-full hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>
      </div>
    </div>
  );
};

PDFReader.propTypes = {
  pdfFile: PropTypes.oneOfType([PropTypes.string, PropTypes.instanceOf(Blob), PropTypes.instanceOf(File)]).isRequired,
  onClose: PropTypes.func.isRequired
};

export default PDFReader;
