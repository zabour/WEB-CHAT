import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Cookies from 'js-cookie';
import book from '/open-book.png';

const apiBaseUrl = import.meta.env.VITE_API_URI;

export default function VerifyEmail() {
  const [verificationCode, setVerificationCode] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();

  // Retrieve the email from cookies
  const email = Cookies.get('recentUser');

  if (!email) {
    return (
      <div className="flex min-h-full flex-1 flex-col justify-center px-6 py-12 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-sm">
          <img
            alt="Your Company"
            src={book}
            className="mx-auto h-28 w-auto"
          />
          <h2 className="mt-10 text-center text-2xl font-bold leading-9 tracking-tight text-gray-900">
            No email found to verify. Please sign up again.
          </h2>
        </div>
      </div>
    );
  }

  const handleVerify = async (event) => {
    event.preventDefault();
    setIsLoading(true);
    setError('');
    setSuccess('');

    if (!verificationCode) {
      setError('Please enter the verification code.');
      setIsLoading(false);
      return;
    }
console.log(email);
    try {
      const response = await fetch(`${apiBaseUrl}/users/verifyEmail/${email}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ verificationCode }),
      });

      if (response.ok) {
        setSuccess('Email successfully verified. Redirecting to sign in...');
        setTimeout(() => {
          navigate('/signin');
        }, 2000);
      } else {
        setError('Invalid verification code or verification failed.');
      }
    } catch (err) {
      console.log(err);
      setError('A problem occurred, please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleResendCode = async () => {
    setIsLoading(true);
    setError('');
    setSuccess('');

    try {
      const response = await fetch(`${apiBaseUrl}/resendVerificationEmail/${email}`, {
        method: 'GET',
      });

      if (response.ok) {
        setSuccess('Verification email resent successfully.');
      } else {
        setError('Failed to resend verification email.');
      }
    } catch (err) {
      console.log(err);
      setError('A problem occurred, please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <div className="flex min-h-full flex-1 flex-col justify-center px-6 py-12 lg:px-8">
        <div className="sm:mx-auto sm:w-full sm:max-w-sm">
          <img
            alt="Your Company"
            src={book}
            className="mx-auto h-28 w-auto"
          />
          <h2 className="mt-10 text-center text-2xl font-bold leading-9 tracking-tight text-gray-900">
            Verify your email
          </h2>
        </div>

        <div className="mt-10 sm:mx-auto sm:w-full sm:max-w-sm">
          {error && (
            <div className="mb-4 text-red-600 text-center">
              {error}
            </div>
          )}
          {success && (
            <div className="mb-4 text-green-600 text-center">
              {success}
            </div>
          )}
          <form onSubmit={handleVerify} className="space-y-6">
            <div>
              <label htmlFor="verificationCode" className="block text-sm font-medium leading-6 text-gray-900">
                Verification Code
              </label>
              <div className="mt-2">
                <input
                  id="verificationCode"
                  name="verificationCode"
                  type="text"
                  value={verificationCode}
                  onChange={(e) => setVerificationCode(e.target.value)}
                  required
                  className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-gray-500 sm:text-sm sm:leading-6"
                />
              </div>
            </div>

            <div>
              <button
                type="submit"
                className="flex w-full justify-center rounded-md bg-black px-3 py-1.5 text-sm font-semibold leading-6 text-white shadow-sm hover:bg-gray-800 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gray-500"
                disabled={isLoading}
              >
                {isLoading ? 'Verifying...' : 'Verify'}
              </button>
            </div>
          </form>

          <div className="mt-4 text-center">
            <button
              onClick={handleResendCode}
              className="text-sm font-semibold leading-6 text-black hover:text-gray-800"
              disabled={isLoading}
            >
              {isLoading ? 'Resending...' : 'Resend verification code'}
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
