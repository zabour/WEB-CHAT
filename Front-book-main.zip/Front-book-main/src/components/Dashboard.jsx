import { useState, useContext } from 'react';
import { Dialog, Transition, Menu } from '@headlessui/react';
import { Bars3Icon, HomeIcon, UsersIcon, XMarkIcon } from '@heroicons/react/24/outline';
import { ChevronDownIcon } from '@heroicons/react/20/solid';
import { Link, useParams } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import ContactsList from './ContactsList';
import book from '/open-book.png';

const navigation = [
  { name: 'Profile', href: 'profile', icon: HomeIcon },
  { name: 'Contacts', href: 'contacts', icon: UsersIcon },
];

function classNames(...classes) {
  return classes.filter(Boolean).join(' ');
}

export default function Dashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { signOut } = useContext(AuthContext);
  const { tab } = useParams();

  const handleSignOut = () => {
    signOut();
  };

  return (
    <>
      <div className="h-full">
        {/* Mobile Sidebar */}
        <Transition.Root show={sidebarOpen} as="div">
          <Dialog as="div" className="relative z-50 lg:hidden" onClose={setSidebarOpen}>
            <Transition.Child
              as="div"
              enter="transition-opacity ease-linear duration-300"
              enterFrom="opacity-0"
              enterTo="opacity-100"
              leave="transition-opacity ease-linear duration-300"
              leaveFrom="opacity-100"
              leaveTo="opacity-0"
            >
              <div className="fixed inset-0 bg-gray-900/80" />
            </Transition.Child>

            <div className="fixed inset-0 flex">
              <Transition.Child
                as="div"
                enter="transition ease-in-out duration-300 transform"
                enterFrom="-translate-x-full"
                enterTo="translate-x-0"
                leave="transition ease-in-out duration-300 transform"
                leaveFrom="translate-x-0"
                leaveTo="-translate-x-full"
              >
                <Dialog.Panel className="relative flex w-full sm:w-2/3 md:w-1/2 flex-1 flex-col bg-white">
                  <div className="flex-1 h-0 pt-5 pb-4 overflow-y-auto">
                    <div className="absolute top-0 right-0 -mr-12 pt-2">
                      <button
                        type="button"
                        className="ml-1 flex items-center justify-center h-10 w-10 rounded-full focus:outline-none focus:bg-gray-600"
                        onClick={() => setSidebarOpen(false)}
                      >
                        <span className="sr-only">Close sidebar</span>
                        <XMarkIcon className="h-6 w-6 text-white" aria-hidden="true" />
                      </button>
                    </div>
                    <nav className="mt-5 px-2 space-y-1">
                      {navigation.map((item) => (
                        <Link
                          key={item.name}
                          to={`/dashboard/${item.href}`}
                          className={classNames(
                            tab === item.href
                              ? 'bg-gray-200 text-black'
                              : 'text-gray-600 hover:bg-gray-200 hover:text-black',
                            'group flex items-center px-2 py-2 text-base font-medium rounded-md'
                          )}
                          onClick={() => setSidebarOpen(false)}
                        >
                          <item.icon
                            className="mr-4 flex-shrink-0 h-6 w-6 text-gray-600"
                            aria-hidden="true"
                          />
                          {item.name}
                        </Link>
                      ))}
                    </nav>
                  </div>
                </Dialog.Panel>
              </Transition.Child>
            </div>
          </Dialog>
        </Transition.Root>

        {/* Desktop Sidebar */}
        <div className="hidden lg:fixed lg:inset-y-0 lg:flex lg:w-64 lg:h-full lg:flex-col lg:bg-white lg:overflow-y-auto">
          <div className="flex items-center h-16 px-4 bg-white">
            <img alt="Your Company" src={book} className="h-8 w-auto" />
          </div>
          <nav className="mt-5 flex-1 px-2 bg-white space-y-1">
            {navigation.map((item) => (
              <Link
                key={item.name}
                to={`/dashboard/${item.href}`}
                className={classNames(
                  tab === item.href
                    ? 'bg-gray-200 text-black'
                    : 'text-gray-600 hover:bg-gray-200 hover:text-black',
                  'group flex items-center px-2 py-2 text-sm font-medium rounded-md'
                )}
              >
                <item.icon className="mr-3 h-6 w-6 text-gray-600" aria-hidden="true" />
                {item.name}
              </Link>
            ))}
          </nav>
        </div>

        <div className="lg:pl-64 flex flex-col flex-1">
          <header className="sticky top-0 z-10 flex-shrink-0 flex h-16 bg-white shadow">
            <button
              type="button"
              className="px-4 border-r border-gray-200 text-gray-500 bg-white focus:outline-none focus:ring-2 focus:ring-inset focus:ring-gray-500 lg:hidden"
              onClick={() => setSidebarOpen(true)}
            >
              <span className="sr-only">Open sidebar</span>
              <Bars3Icon className="h-6 w-6" aria-hidden="true" />
            </button>
            <div className="flex-1 px-4 flex justify-between">
              <div className="flex-1 flex items-center"></div>
              <div className="ml-4 flex items-center lg:ml-6">
                <Menu as="div" className="relative">
                  <div>
                    <Menu.Button className="max-w-xs bg-white rounded-full flex items-center text-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500">
                      <span className="sr-only">Open user menu</span>
                      <img
                        alt="User avatar"
                        src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80"
                        className="h-8 w-8 rounded-full"
                      />
                      <ChevronDownIcon className="ml-2 h-5 w-5 text-gray-500" aria-hidden="true" />
                    </Menu.Button>
                  </div>
                  <Transition
                    as={Menu.Items}
                    className="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none"
                    enter="transition ease-out duration-100"
                    enterFrom="transform opacity-0 scale-95"
                    enterTo="transform opacity-100 scale-100"
                    leave="transition ease-in duration-75"
                    leaveFrom="transform opacity-100 scale-100"
                    leaveTo="transform opacity-0 scale-95"
                  >
                    <div className="py-1">
                      <Menu.Item>
                        {({ active }) => (
                          <Link
                            to="/signin"
                            className={classNames(
                              active ? 'bg-gray-100' : '',
                              'block px-4 py-2 text-sm text-gray-700'
                            )}
                            onClick={handleSignOut}
                          >
                            Sign out
                          </Link>
                        )}
                      </Menu.Item>
                    </div>
                  </Transition>
                </Menu>
              </div>
            </div>
          </header>

          <main className="flex-1 bg-white">
            <div className="py-6">
              <div className="px-4 sm:px-6 lg:px-8">
                {tab === 'profile' && <div>Your Profile Content</div>}
                {tab === 'contacts' && <ContactsList />}
              </div>
            </div>
          </main>
        </div>
      </div>
    </>
  );
}
