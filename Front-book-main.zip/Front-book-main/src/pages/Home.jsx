import FAQ from "../components/FAQ"
import Footer from "../components/Footer"
import Header from "../components/Header"
import Hero from "../components/Hero"
import ImageGrid from "../components/ImagesGridList"
import LogoCloud from "../components/LogoCloud"

export default function Home() {
  return (
    <><Header></Header>
    <Hero></Hero>
    <LogoCloud></LogoCloud>
    <ImageGrid></ImageGrid>
    <FAQ></FAQ>
      <Footer></Footer>
      </>
  )
}
