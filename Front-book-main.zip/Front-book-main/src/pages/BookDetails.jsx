import { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import PropTypes from 'prop-types';
import { Loader2 } from 'lucide-react';
import PDFReader from '../components/PdfReader';
import Header from '../components/Header';
import Footer from '../components/Footer';
import Cookies from "js-cookie";

const BookDetails = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const book = location.state?.book;

  const [isReading, setIsReading] = useState(false);
  const [pdfUrl, setPdfUrl] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!book) {
      navigate('/books');
    }
  }, [book, navigate]);

  if (!book) return null;

  const handleReserve = async () => {
    try {
      setIsLoading(true);
      setError(null);
  
      const token = Cookies.get("token");
      if (!token) {
        setError("You need to be logged in to reserve a book.");
        return;
      }
  
      const response = await fetch("http://localhost:10000/reservation/add", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          userId: JSON.parse(Cookies.get("user"))._id,
          bookId: book._id,
        }),
      });
  
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to reserve book");
      }
  
      const data = await response.json();
      console.log("Reservation successful:", data);
  
      // Update the book's reserved status in the UI
      book.reserved = true;
  
      alert("Book successfully reserved!");
    } catch (err) {
      setError(err.message || "Failed to reserve book");
      console.error("Reserve error:", err);
    } finally {
      setIsLoading(false);
    }
  };
  

  const handleRead = async () => {
    try {
      setIsLoading(true);
      setError(null);
 const token = Cookies.get("token");
      if (book._id) {
        // Get the PDF through the download endpoint
        const response = await fetch(`http://localhost:10000/books/download-pdf/${book._id}`, {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });

        if (!response.ok) {
          throw new Error('Failed to fetch PDF');
        }

        // Create a blob URL from the PDF response
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        setPdfUrl(url);
        setIsReading(true);
      } else {
        throw new Error('PDF not available');
      }
    } catch (err) {
      setError('Failed to load book content');
      console.error('Read error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Function to get image URL
  const getImageUrl = (bookId) => {
    if (!bookId) return "https://via.placeholder.com/150";
    return `http://localhost:10000/books/get-image/${bookId}`;
  };

  useEffect(() => {
    return () => {
      if (pdfUrl) {
        window.URL.revokeObjectURL(pdfUrl);
      }
    };
  }, [pdfUrl]);

  return (
    <>
      <Header />
      <div className="min-h-screen bg-white py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-md">
              <p className="text-red-600">{error}</p>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="space-y-6">
              <div className="aspect-[2/3] w-full overflow-hidden rounded-lg shadow-lg">
                <img
                  src={getImageUrl(book._id)}
                  alt={book.name}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    e.target.onerror = null;
                    e.target.src = "https://via.placeholder.com/150";
                  }}
                />
              </div>
              
              <div className="flex gap-4">
                <button
                  onClick={handleReserve}
                  disabled={isLoading || book.reserved}
                  className="flex-1 bg-black text-white py-3 rounded-md hover:bg-gray-800 transition-colors duration-200 disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {isLoading ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    'Reserve Book'
                  )}
                </button>
                <button
                  onClick={handleRead}
                  disabled={isLoading}
                  className="flex-1 bg-white text-black border-2 border-black py-3 rounded-md hover:bg-gray-100 transition-colors duration-200 disabled:bg-gray-100 disabled:border-gray-300 disabled:text-gray-400 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {isLoading ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    'Read Now'
                  )}
                </button>
              </div>
            </div>

            <div className="space-y-6">
              <h1 className="text-4xl font-bold text-black">{book.name}</h1>
              <p className="text-2xl text-gray-600">by {book.auteurs}</p>
              
              <div className="space-y-4 border-t border-gray-200 pt-6">
                <div className="grid grid-cols-2 gap-4">
                  <DetailItem label="Genre" value={book.genre} />
                  <DetailItem label="Pages" value={book.nb_page} />
                  <DetailItem label="Language" value={book.language || 'Not specified'} />
                  <DetailItem label="Edition Date" value={book.date_edition || 'Not specified'} />
                  <DetailItem label="Price" value={book.prix || 'Not specified'} />
                  <DetailItem label="ISBN" value={book.isbn || 'Not specified'} />
                  <DetailItem 
                    label="Availability" 
                    value={!book.reserved ? "Available" : "Not Available"}
                    className={!book.reserved ? "text-green-600" : "text-red-600"}
                  />
                </div>
              </div>

              <div className="border-t border-gray-200 pt-6">
                <h2 className="text-xl font-semibold mb-4">Description</h2>
                <p className="text-gray-600 leading-relaxed">
                  {book.description || 'No description available.'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {isReading && pdfUrl && (
        <PDFReader 
          pdfFile={pdfUrl}
          onClose={() => {
            setIsReading(false);
            setPdfUrl(null);
          }}
        />
      )}
      <Footer />
    </>
  );
};

const DetailItem = ({ label, value, className = "text-gray-800" }) => (
  <div>
    <dt className="text-sm text-gray-600">{label}</dt>
    <dd className={`text-base font-medium ${className}`}>{value}</dd>
  </div>
);

DetailItem.propTypes = {
  label: PropTypes.string.isRequired,
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
  className: PropTypes.string
};

DetailItem.defaultProps = {
  className: "text-gray-800"
};

export default BookDetails;