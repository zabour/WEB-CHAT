import { useEffect, useState } from 'react';
import Cookies from "js-cookie";

const Profile = () => {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  // Fetch user data from localStorage
  useEffect(() => {
    const userData = JSON.parse(localStorage.getItem('user'));
    if (userData) {
      setProfile(userData);  // Set user data from localStorage to profile
    }
    setLoading(false);  // Set loading to false once data is fetched
  }, []);  // Empty dependency array ensures it only runs once when the component mounts

  // Convert the Buffer QR code data to a base64 string
  const qrCodeImage = profile?.qrCode?.data 
    ? `data:image/png;base64,${btoa(String.fromCharCode(...new Uint8Array(profile.qrCode.data)))}`
    : null;

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="container mx-auto p-8 bg-white text-gray-800 rounded-lg shadow-lg">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-black">{profile?.firstName} {profile?.lastName}</h1>
        <p className="text-lg text-gray-600">{profile?.email}</p>
      </div>

      <div className="mt-10">
        <h2 className="text-2xl font-semibold text-black mb-4">Your Profile</h2>

        <div className="flex flex-col items-center">
          <h3 className="text-xl font-medium text-black mb-4">Your QR Code</h3>

          {qrCodeImage ? (
            <img src={qrCodeImage} alt="QR Code" className="w-48 h-48 border border-gray-300 rounded-lg shadow-sm" />
          ) : (
            <p className="text-gray-500">Loading QR Code...</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default Profile;
