import { useState } from "react";
import useFetch from "../hooks/useFetch";
import Header from "../components/Header";

const ChatPage = () => {
  const [input, setInput] = useState("");
  const [response, setResponse] = useState("");
  const { fetchData, loading } = useFetch("http://localhost:3003");

  const handleSubmit = async (e) => {
    e.preventDefault();

    const result = await fetchData({
      endpoint: "/generate",
      method: "POST",
      body: { prompt: input },
    });

    if (result.success) {
      setResponse(formatResponse(result.data.response));
      setInput("");
    }
  };

  const formatResponse = (responseText) => {
    let formattedText = responseText;
    formattedText = formattedText.replace(
      /\*\*(.*?)\*\*/g,
      "<strong>$1</strong>"
    );
    formattedText = formattedText.replace(
      /(\d+\.)\s(.*?)(?=\n|$)/g,
      "<li>$2</li>"
    );
    formattedText = formattedText.replace(/\n/g, "<br />");
    formattedText = formattedText.replace(
      /(^|\n)(-|\*)\s(.*?)(?=\n|$)/g,
      "<ul><li>$3</li></ul>"
    );
    return formattedText;
  };

  return (
    <>
      <Header></Header>
      <div className="min-h-screen bg-white flex flex-col">
        {/* Header */}
        <div className="bg-black text-white p-6">
          <h2 className="text-2xl font-bold text-center">Chat with me!</h2>
        </div>

        {/* Chat Area */}
        <div className="flex-grow p-6 overflow-y-auto">
          {loading && (
            <div className="text-center py-4">
              <div className="animate-pulse text-gray-600">Processing...</div>
            </div>
          )}

          {response && (
            <div className="bg-gray-50 rounded-lg p-6 shadow-sm mb-6">
              <div
                className="prose max-w-none"
                dangerouslySetInnerHTML={{ __html: response }}
              />
            </div>
          )}
        </div>

        {/* Input Form */}
        <form onSubmit={handleSubmit} className="border-t border-gray-200 p-6">
          <div className="max-w-4xl mx-auto flex gap-4">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type your message here..."
              className="flex-grow px-4 py-3 border-2 border-gray-200 rounded-lg focus:outline-none focus:border-black transition-colors"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="px-8 py-3 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
            >
              Send
            </button>
          </div>
        </form>
      </div>
    </>
  );
};

export default ChatPage;
