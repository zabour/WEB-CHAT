import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Header from "../components/Header";
import Footer from "../components/Footer";
import useFetch from "../hooks/useFetch";

const BooksPage = () => {
  const [books, setBooks] = useState([]);
  const { fetchData, loading, error } = useFetch("http://localhost:10000");
  const [selectedGenre, setSelectedGenre] = useState("All");
  const [currentPage, setCurrentPage] = useState(1);
  const booksPerPage = 15;
  const navigate = useNavigate();

  // const fetchBooks = async () => {
  //   const response = await fetchData({
  //     endpoint: "/books/getAll",
  //     method: "GET",
  //   });

  //   if (response.success) {
  //     setBooks(response.data);
  //   } else {
  //     console.log("Error fetching books:", response.message);
  //   }
  // };

  // useEffect(() => {
  //   fetchBooks();
  // }, []);

  const genres = ["All", "Big data", "Science", "IT", "Management", "BI"];

  const filteredBooks = selectedGenre === "All"
    ? books
    : books.filter((book) => book.genre === selectedGenre);

  const totalPages = Math.ceil(filteredBooks.length / booksPerPage);
  const startIndex = (currentPage - 1) * booksPerPage;
  const displayedBooks = filteredBooks.slice(startIndex, startIndex + booksPerPage);
  const pageNumbers = Array.from({ length: totalPages }, (_, i) => i + 1);

  const handleBookClick = (book) => {
    navigate('/bookDetail', { state: { book } });
  };

  const getImageUrl = (bookId) => {
    if (!bookId) return "https://via.placeholder.com/150";
    return `http://localhost:10000/books/get-image/${bookId}`;
  };

  if (loading) {
    return (
      <>
        <Header />
        <div className="min-h-screen bg-white p-8 flex items-center justify-center">
          <div className="text-xl">Loading books...</div>
        </div>
        <Footer />
      </>
    );
  }

  if (error) {
    return (
      <>
        <Header />
        <div className="min-h-screen bg-white p-8 flex items-center justify-center">
          <div className="text-xl text-red-500">{error}</div>
        </div>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Header />
      <div className="min-h-screen bg-white p-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-black mb-4">Books Collection</h1>
          {/* <select
            value={selectedGenre}
            onChange={(e) => setSelectedGenre(e.target.value)}
            className="w-64 px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-gray-400"
          >
            {genres.map((genre) => (
              <option key={genre} value={genre}>{genre}</option>
            ))}
          </select> */}
        </div>

        <div className="grid grid-cols-5 gap-8 mb-8">
          {/* {displayedBooks.map((book) => (
            <div
              key={book._id}
              className="bg-white border border-gray-200 rounded-lg hover:shadow-lg transition-shadow cursor-pointer"
              onClick={() => handleBookClick(book)}
            >
              <div className="p-6">
                <div className="aspect-[3/4] mb-4 overflow-hidden rounded-md">
                  <img
                    src={getImageUrl(book._id)}
                    alt={book.name}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                    onError={(e) => {
                      e.target.onerror = null;
                      e.target.src = "https://via.placeholder.com/150";
                    }}
                  />
                </div>
                <h4 className="text-black font-semibold text-center">{book.name}</h4>
              </div>
            </div>
          ))} */}
        </div>

        <div className="flex justify-center gap-2">
          <button
            onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
            disabled={currentPage === 1}
            className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Previous
          </button>

          {pageNumbers.map((number) => (
            <button
              key={number}
              onClick={() => setCurrentPage(number)}
              className={`px-4 py-2 rounded-md ${
                currentPage === number
                  ? "bg-black text-white"
                  : "border border-gray-300 hover:bg-gray-100"
              }`}
            >
              {number}
            </button>
          ))}

          <button
            onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
            disabled={currentPage === totalPages}
            className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Next
          </button>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default BooksPage;