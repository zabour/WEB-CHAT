import { useContext } from "react";
import { AuthProvider, AuthContext } from "./context/AuthContext";
import "./App.css";
import {
  BrowserRouter as Router,
  Route,
  Routes,
  Navigate,
  Outlet,
} from "react-router-dom";

import Signin from "./components/Signin";
import Dashboard from "./components/Dashboard";
import Signup from "./components/Signup";
import NotfoundPage from "./components/NotfoundPage";
import VerifyEmail from "./components/VerifyEmail";
import ScrollToTop from "./utils/ScrollToTop";
import Home from "./pages/Home";
import BooksPage from "./pages/Books";
import BookDetails from "./pages/BookDetails";
import ChatPage from "./pages/ChatPage";
import Profile from "./pages/Profile";

const ProtectedRoute = () => {
  const { isAuthenticated } = useContext(AuthContext);

  if (!isAuthenticated) {
    return <Signin />;
  }

  return <Outlet />;
};

const AppLayout = () => <Outlet />;

const App = () => {
  return (
    <AuthProvider>
      <Router>
        <ScrollToTop />
        <Routes>
          <Route element={<AppLayout />}>
            {/* Redirect from root to /signin */}
            <Route path="/" element={<Navigate to="/signin" replace />} />
            <Route path="/signin" element={<Signin />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/home" element={<Home />} />
            <Route path="/books" element={<BooksPage />} />
            <Route path="/bookDetail" element={<BookDetails />} />
            <Route path="/chat" element={<ChatPage />} />
            <Route path="/profile" element={<Profile />} />
          </Route>
          {/* <Route element={<ProtectedRoute />}> */}
            <Route path="/dashboard/:tab" element={<Dashboard />} />
          {/* </Route> */}
          <Route path="/verifyEmail" element={<VerifyEmail />} />
          <Route path="*" element={<NotfoundPage />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
};

export default App;
