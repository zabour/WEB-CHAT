import { useState, useCallback } from 'react';

const useFetch = (baseURL = '') => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const getResponseMessage = (status) => {
    const messages = {
      200: 'Request successful',
      201: 'Resource created successfully',
      204: 'No content',
      400: 'Bad request - please check your input',
      401: 'Unauthorized - please login again',
      403: 'Forbidden - you don\'t have permission',
      404: 'Resource not found',
      500: 'Internal server error',
      502: 'Bad gateway',
      503: 'Service unavailable'
    };
    return messages[status] || 'Something went wrong';
  };

  const fetchData = useCallback(async ({
    endpoint,
    method = 'GET',
    body = null,
    headers = {},
    withToken = false,
  }) => {
    setLoading(true);
    setError(null);

    try {
      // Add token to headers if required
      if (withToken) {
        const token = localStorage.getItem('token');
        headers = {
          ...headers,
          'Authorization': `Bearer ${token}`
        };
      }

      // Add default headers for JSON requests
      const isFormData = body instanceof FormData;
      if (!isFormData) {
        headers = {
          'Content-Type': 'application/json',
          ...headers
        };
      }

      const requestOptions = {
        method: method.toUpperCase(),
        headers,
        ...(body && {
          body: isFormData ? body : JSON.stringify(body)
        })
      };

      const response = await fetch(`${baseURL}${endpoint}`, requestOptions);
      let data = null;
      
      // Try to parse JSON response, fall back to text if not JSON
      try {
        data = await response.json();
      } catch {
        data = await response.text();
      }

      setLoading(false);

      return {
        success: response.ok,
        status: response.status,
        message: getResponseMessage(response.status),
        data,
      };

    } catch (err) {
      setLoading(false);
      setError(err);
      
      return {
        success: false,
        status: 0,
        message: 'Network error - please check your connection',
        data: null
      };
    }
  }, [baseURL]);

  return {
    fetchData,
    loading,
    error
  };
};

export default useFetch;